﻿namespace CUSTInformations.Models
{
    public class PurchasesPerMonths
    {
       public Dictionary<string, int> distinctCustomers = new Dictionary<string, int>(); 
    }
}
