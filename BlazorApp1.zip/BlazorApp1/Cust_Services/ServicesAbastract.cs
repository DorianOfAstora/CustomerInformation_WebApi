﻿using Cust_Services.Service_Models;

namespace Cust_Services
{
    public abstract class ServicesAbastract
    {
        public static Uri Baseurl = new Uri("https://localhost:7017/");
        public static HttpClient client = new HttpClient();
        public abstract string Customer();
    }
}