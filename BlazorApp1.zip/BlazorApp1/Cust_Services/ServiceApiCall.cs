﻿using Cust_Services.Service_Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Cust_Services.Service_Models.CustomerModels;

namespace Cust_Services
{
    public class ServiceApiCall : ServicesAbastract
    {
        public override string Customer()
        {
            var resModel = string.Empty;
            using (var client = new HttpClient())
            {
                client.BaseAddress = Baseurl;
                client.DefaultRequestHeaders.Accept.Clear();
                HttpResponseMessage response = new HttpResponseMessage();
                response = client.GetAsync(Baseurl + "api/Purchases/GetPurchaseFileRecords").GetAwaiter().GetResult();
                resModel = response.Content.ReadAsStringAsync().Result;
            }
            return resModel;
        }
    }
}
