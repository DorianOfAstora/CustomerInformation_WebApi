﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cust_BL.BL_Models
{
    public class CustomerModels
    {
        public class CustomerResultViewModel
        {
            public List<CustomerResViewModel> customerList { get; set; }
            public string item { get; set; }
            public int uniqueCustomer { get; set; }
        }
        public class CustomerResViewModel
        {
            public string customerList { get; set; }
        }
    }
}
