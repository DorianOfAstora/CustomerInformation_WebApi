﻿using Cust_BL.BL_Models;

namespace Cust_BL
{
    public abstract class BuAbstract
    {
        public abstract List<CustomerModels.CustomerResultViewModel> Customer();
    }
}