﻿using Cust_BL.BL_Models;
using Cust_Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cust_BL
{
    public class Bu_Elaborator : BuAbstract
    {
        public override List<CustomerModels.CustomerResultViewModel> Customer ()
        {
            var res = new List<CustomerModels.CustomerResultViewModel>();
            var jsonResult = new ServicesAbastract().Customer();
            return res;
        }
    }
}
